#include "GameManager.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cstdlib>
#include <ctime>
#include <iostream> 

// CLO1: Hàm khởi tạo
GameManager::GameManager()
    : mWindow()
    , mPlayer(400.f) // Tốc độ player
    , mIsPlaying(false)
    , mScore(0)
    , mTimeSinceLastSpawn(sf::Time::Zero)
    , mRoadSpeed(300.f) 
    , mRoadPadding(100.f) // Giá trị mặc định
{
    // CLO4: Đọc file config
    loadConfig("config.ini"); 

    // CLO1: Tạo màn hình
    mWindow.create(sf::VideoMode(mWindowWidth, mWindowHeight), "Car Racing");
    mWindow.setFramerateLimit(60);

    srand(static_cast<unsigned int>(time(0)));

    // Tải tài nguyên
    loadResources(); 
    
    // Tạo đường đua
    setupRoad(); 

    setupTexts();
    
    // CLO4: Đọc file điểm
    loadScoreboard(); 

    resetGame();
}

// CLO4: Đọc file cấu hình (config.ini)
void GameManager::loadConfig(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        // CLO4: Xử lý ngoại lệ 1: File không tồn tại
        throw std::runtime_error("CLO4 Exception: Config file not found! (" + filename + ")");
    }

    std::string line;
    while (std::getline(file, line))
    {
        // Bỏ qua các dòng trống hoặc dòng comment
        if (line.empty() || line[0] == '#')
        {
            continue;
        }

        std::stringstream ss(line);
        std::string key;
        float value;
        
        if (std::getline(ss, key, '=') && (ss >> value))
        {
            if (key == "width") mWindowWidth = static_cast<int>(value);
            else if (key == "height") mWindowHeight = static_cast<int>(value);
            else if (key == "enemy_speed_min") mEnemySpeedMin = value;
            else if (key == "enemy_speed_max") mEnemySpeedMax = value;
            else if (key == "spawn_interval") mSpawnInterval = value;
            else if (key == "road_speed") mRoadSpeed = value; 
            else if (key == "road_padding") mRoadPadding = value;
        }
        else
        {
            // CLO4: Xử lý ngoại lệ 2: Dữ liệu sai định dạng
            file.close();
            throw std::runtime_error("CLO4 Exception: Bad config file format in " + filename + " -> line: " + line);
        }
    }
    file.close();
}

// *** HÀM ĐÃ SỬA ***
void GameManager::loadResources()
{
    // ... (Code load "arial.ttf" giữ nguyên) ...
    if (!mFont.loadFromFile("arial.ttf"))
    {
        throw std::runtime_error("CLO4 Exception: Font file not found (arial.ttf)");
    }
    
    // Tải texture player
    mPlayer.initTexture("player_car.png"); 

    // *** THAY ĐỔI: Load nhiều ảnh enemy vào vector ***
    
    // 1. Tải xe 1 (Ví dụ: xe màu đỏ)
    sf::Texture tex1;
    if (!tex1.loadFromFile("enemy_car_1.png"))
    {
        throw std::runtime_error("CLO4 Exception: File Not Found: enemy_car_1.png");
    }
    mEnemyTextures.push_back(tex1); // Thêm vào vector

    // 2. Tải xe 2 (Ví dụ: xe màu xanh)
    sf::Texture tex2;
    if (!tex2.loadFromFile("enemy_car_2.png"))
    {
        throw std::runtime_error("CLO4 Exception: File Not Found: enemy_car_2.png");
    }
    mEnemyTextures.push_back(tex2); // Thêm vào vector

    // (Bạn có thể lặp lại để tải "enemy_car_3.png", v.v... nếu muốn)
}

// HÀM MỚI: Cài đặt vạch kẻ đường
void GameManager::setupRoad()
{
    // ---- 1. VẼ 2 LỀ ĐƯỜNG (VẠCH LIỀN) ----
    mRoadEdgeLeft.setSize(sf::Vector2f(10.f, mWindowHeight)); // Rộng 10px, cao full
    mRoadEdgeLeft.setFillColor(sf::Color::White);
    mRoadEdgeLeft.setPosition(mRoadPadding, 0.f); // Đặt ở vị trí padding

    mRoadEdgeRight.setSize(sf::Vector2f(10.f, mWindowHeight));
    mRoadEdgeRight.setFillColor(sf::Color::White);
    mRoadEdgeRight.setPosition(mWindowWidth - mRoadPadding - 10.f, 0.f); // Đặt ở mép bên kia

    // ---- 2. VẼ VẠCH KẺ GIỮA (ĐƯỜNG 2 LÀN) ----
    sf::Vector2f lineSize(10.f, 100.f); // Rộng 10px, Cao 100px
    
    // Vị trí X (Chính giữa của con đường, không phải cửa sổ)
    float lineX = mRoadPadding + ((mWindowWidth - mRoadPadding * 2) / 2.f);
    
    float lineHeight = lineSize.y;
    float lineSpacing = 150.f; // Khoảng cách dọc giữa 2 vạch
    
    int numLines = (mWindowHeight / (lineHeight + lineSpacing)) + 2;

    for (int i = 0; i < numLines; ++i)
    {
        sf::RectangleShape line;
        line.setSize(lineSize);
        line.setFillColor(sf::Color::White);
        line.setOrigin(lineSize.x / 2.f, lineSize.y / 2.f);
        line.setPosition(lineX, i * (lineHeight + lineSpacing));
        mLaneLines.push_back(line);
    }
}

void GameManager::setupTexts()
{
    mScoreText.setFont(mFont);
    mScoreText.setCharacterSize(24);
    mScoreText.setFillColor(sf::Color::White);
    mScoreText.setPosition(10.f, 10.f);

    mGameOverText.setFont(mFont);
    mGameOverText.setCharacterSize(40);
    mGameOverText.setFillColor(sf::Color::Red);
    mGameOverText.setString("GAME OVER!\nPress Enter to Restart");
    
    sf::FloatRect textRect = mGameOverText.getLocalBounds();
    mGameOverText.setOrigin(textRect.left + textRect.width / 2.0f,
                            textRect.top + textRect.height / 2.0f);
    mGameOverText.setPosition(mWindowWidth / 2.0f, mWindowHeight / 2.0f);
}

void GameManager::resetGame()
{
    mIsPlaying = true;
    mScore = 0;
    mScoreText.setString("Score: 0");
    mTimeSinceLastSpawn = sf::Time::Zero;
    mEnemies.clear(); // CLO3: Xóa vector

    // Đặt player ở giữa đường đua
    float playerStartX = mRoadPadding + ((mWindowWidth - mRoadPadding * 2) / 2.f);
    mPlayer.setPosition(playerStartX, mWindowHeight - mPlayer.getGlobalBounds().height);
}

void GameManager::run()
{
    sf::Clock clock;
    while (mWindow.isOpen())
    {
        sf::Time dt = clock.restart();
        processEvents();
        if (mIsPlaying)
        {
            update(dt);
        }
        render();
    }
}

// CLO1: Xử lý sự kiện
void GameManager::processEvents()
{
    sf::Event event;
    while (mWindow.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
            mWindow.close();

        if (!mIsPlaying && event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Enter)
        {
            resetGame();
        }
    }
}

// CLO1: Cập nhật trạng thái
void GameManager::update(sf::Time dt)
{
    // CẬP NHẬT VẠCH KẺ ĐƯỜNG (Giữa)
    for (auto& line : mLaneLines)
    {
        line.move(0, mRoadSpeed * dt.asSeconds());
        if (line.getPosition().y - line.getSize().y / 2.f > mWindowHeight)
        {
            float totalHeight = (mLaneLines.size()) * (line.getSize().y + 150.f);
            line.move(0, -totalHeight); 
        }
    }

    // Cập nhật Player
    mPlayer.update(dt);
    
    // Giữ player BÊN TRONG lề đường
    sf::Vector2f playerPos = mPlayer.getPosition();
    float playerHalfWidth = mPlayer.getGlobalBounds().width / 2.f;
    
    // Tính toán giới hạn trái và phải
    float leftLimit = mRoadPadding + playerHalfWidth + 10.f; // +10f là độ rộng vạch lề
    float rightLimit = mWindowWidth - mRoadPadding - playerHalfWidth - 10.f;

    if (playerPos.x < leftLimit)
        mPlayer.setPosition(leftLimit, playerPos.y);
    if (playerPos.x > rightLimit)
        mPlayer.setPosition(rightLimit, playerPos.y);

    // Cập nhật thời gian spawn
    mTimeSinceLastSpawn += dt;
    if (mTimeSinceLastSpawn.asSeconds() > mSpawnInterval)
    {
        spawnEnemy();
        mTimeSinceLastSpawn = sf::Time::Zero;
    }

    // Cập nhật enemies
    for (auto it = mEnemies.begin(); it != mEnemies.end(); )
    {
        it->update(dt);
        if (it->getPosition().y > mWindowHeight + it->getGlobalBounds().height)
        {
            it = mEnemies.erase(it); 
            mScore++; 
        }
        else
        {
            ++it;
        }
    }
    
    mScoreText.setString("Score: " + std::to_string(mScore));

    // Kiểm tra va chạm
    checkCollisions();
}

// CLO1: Vẽ màn hình
void GameManager::render()
{
    mWindow.clear(sf::Color(50, 50, 50)); // Màu đường đua xám
    
    // VẼ LỀ ĐƯỜNG (VẠCH LIỀN)
    mWindow.draw(mRoadEdgeLeft);
    mWindow.draw(mRoadEdgeRight);

    // VẼ VẠCH KẺ ĐƯỜNG (GIỮA)
    for (const auto& line : mLaneLines)
    {
        mWindow.draw(line);
    }

    // Vẽ xe
    mPlayer.draw(mWindow);
    for (auto& enemy : mEnemies)
    {
        enemy.draw(mWindow);
    }

    // Vẽ Text
    mWindow.draw(mScoreText);

    if (!mIsPlaying)
    {
        mWindow.draw(mGameOverText);
    }

    mWindow.display();
}

// *** HÀM ĐÃ SỬA ***
void GameManager::spawnEnemy()
{
    // Fix: Kiểm tra xem có xe nào còn ở quá gần đỉnh không
    for (const auto& enemy : mEnemies)
    {
        if (enemy.getPosition().y < 150.f)
        {
            return; // BỎ QUA, không spawn
        }
    }
    
    // Nếu không có xe nào ở trên đỉnh, thì mới spawn xe mới
    float speed = mEnemySpeedMin + (rand() % static_cast<int>(mEnemySpeedMax - mEnemySpeedMin + 1));
    
    // *** THAY ĐỔI: Chọn ngẫu nhiên 1 texture từ vector ***
    if (mEnemyTextures.empty()) return; // An toàn, tránh crash nếu load lỗi

    // Chọn ngẫu nhiên một index (ví dụ: 0 hoặc 1)
    int textureIndex = rand() % mEnemyTextures.size(); 
    
    // Truyền texture đã chọn
    mEnemies.emplace_back(speed, mEnemyTextures[textureIndex]); 
    
    // (Phần code còn lại của hàm spawnEnemy giữ nguyên)
    Enemy& newEnemy = mEnemies.back();
    float enemyHalfWidth = newEnemy.getGlobalBounds().width / 2.f;

    // Tính toán khu vực spawn (bên trong lề đường)
    int spawnableWidth = (mWindowWidth - mRoadPadding * 2) - static_cast<int>(enemyHalfWidth * 2) - 20; // -20 cho 2 vạch lề

    if (spawnableWidth <= 0) // Nếu đường quá hẹp
    {
        // Spawn ở giữa đường
        float xPos = mRoadPadding + ((mWindowWidth - mRoadPadding * 2) / 2.f);
        newEnemy.setPosition(xPos, -100.f);
    }
    else
    {
        // Spawn ngẫu nhiên trong khu vực
        float xPos = static_cast<float>(rand() % spawnableWidth) + mRoadPadding + enemyHalfWidth + 10.f;
        newEnemy.setPosition(xPos, -100.f); 
    }
}

// SỬA LỖI HITBOX (Tạo hitbox nhỏ hơn)
void GameManager::checkCollisions()
{
    sf::FloatRect playerBounds = mPlayer.getGlobalBounds();
    float paddingX = 10.f; 
    float paddingY = 10.f;
    
    sf::FloatRect playerHitbox(
        playerBounds.left + paddingX,
        playerBounds.top + paddingY,
        playerBounds.width - (paddingX * 2),
        playerBounds.height - (paddingY * 2)
    );
    
    for (const auto& enemy : mEnemies)
    {
        sf::FloatRect enemyBounds = enemy.getGlobalBounds();
        sf::FloatRect enemyHitbox(
            enemyBounds.left + paddingX,
            enemyBounds.top + paddingY,
            enemyBounds.width - (paddingX * 2),
            enemyBounds.height - (paddingY * 2)
        );

        // Kiểm tra va chạm bằng hitbox
        if (playerHitbox.intersects(enemyHitbox))
        {
            mIsPlaying = false; // Game over
            mScoreboard.insert({mScore, "Player"}); 
            saveScoreboard(); 
            break;
        }
    }
}


// CLO4: Đọc/Lưu file scoreboard
void GameManager::loadScoreboard()
{
    std::ifstream file("scoreboard.txt");
    if (!file.is_open())
    {
        return; 
    }
    
    int score;
    std::string name;
    while (file >> score >> name)
    {
        mScoreboard.insert({score, name}); 
    }
    file.close();
}

void GameManager::saveScoreboard()
{
    std::ofstream file("scoreboard.txt");
    if (!file.is_open())
    {
        std::cerr << "Warning: Could not save scoreboard." << std::endl;
        return;
    }
    
    int count = 0;
    for (const auto& pair : mScoreboard)
    {
        file << pair.first << " " << pair.second << "\n";
        if (++count >= 10) break;
    }
    file.close();
}