#pragma once

#include <SFML/Graphics.hpp>
#include "Player.h"
#include "Enemy.h"
#include <vector>       // Sử dụng STL vector (CLO3)
#include <map>          // Sử dụng STL map (CLO3)
#include <string>
#include <memory>

class GameManager
{
public:
    GameManager();
    void run(); // Hàm chạy game loop chính

private:
    // Các hàm xử lý rõ ràng (CLO1)
    void processEvents();   // Xử lý sự kiện
    void update(sf::Time dt); // Cập nhật trạng thái game
    void render();          // Vẽ màn hình

    // Các hàm khởi tạo và tài nguyên
    void loadConfig(const std::string& filename); // CLO4: Đọc file config
    void loadResources();
    void setupTexts();
    
    // Hàm cài đặt vạch kẻ đường
    void setupRoad(); 

    // Các hàm xử lý logic game
    void spawnEnemy();
    void checkCollisions(); // Hàm kiểm tra va chạm (theo yêu cầu ảnh 2)
    void resetGame();
    
    // Hàm xử lý file điểm (CLO4)
    void loadScoreboard();
    void saveScoreboard();

private:
    // Các lớp đối tượng (CLO2)
    sf::RenderWindow mWindow;
    Player mPlayer;

    // Biến lề đường
    sf::RectangleShape mRoadEdgeLeft;   // Lề đường trái
    sf::RectangleShape mRoadEdgeRight;  // Lề đường phải
    float mRoadPadding;                 // Khoảng cách lề

    // *** THAY ĐỔI: Vector chứa nhiều texture enemy ***
    std::vector<sf::Texture> mEnemyTextures; 

    // CLO3: Sử dụng std::vector để quản lý danh sách đối thủ
    std::vector<Enemy> mEnemies; 

    // CLO3: Sử dụng std::map để quản lý điểm số
    std::multimap<int, std::string, std::greater<int>> mScoreboard; 

    // Các biến cho vạch kẻ giữa
    std::vector<sf::RectangleShape> mLaneLines; 
    float mRoadSpeed;                           

    // Biến quản lý game
    sf::Font mFont;
    sf::Text mScoreText;
    sf::Text mGameOverText;

    bool mIsPlaying;
    int mScore;

    // Các biến đọc từ file config (CLO4)
    int mWindowWidth;
    int mWindowHeight;
    float mEnemySpeedMin;
    float mEnemySpeedMax;
    float mSpawnInterval;
    sf::Time mTimeSinceLastSpawn;
};